# stock-movement-prediction-using-hmm-in-python
This python script predicts stock movement for next day.
